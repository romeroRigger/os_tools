'''
A python package that helps you to find a job based on a data base updated weekly
'''
from jr_jobFinder import jr_jobFinderMaya
jr_jobFinderMaya.ui()
