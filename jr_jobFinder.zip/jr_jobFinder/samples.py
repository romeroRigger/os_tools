from functools import partial
import json
import os
import re
from functools import partial
import logging
import requests as requests
from lxml import html


class sample_data():
    def __init__(self, version_url='https://raw.githubusercontent.com/romeroRigger/CGjobs/master/version.html',
                 folder_path='{}/data'.format(os.path.dirname(os.path.realpath(__file__))),
                 data_file='job_data.json'):
        self.version_url = version_url
        self.file_path = '{}/{}'.format(folder_path, data_file)
        self.data_file = data_file

    def data_req(self, *args):
        page = requests.get(self.version_url)
        tree = html.fromstring(page.content)
        self.remote_version = tree.xpath('//div[@id="version"]/text()')[0]
        self.offline_version()

    def offline_version(self, *args):
        with open(self.file_path) as job_data:
            data = json.load(job_data)
            self.local_version = data["version"]
            if self.local_version == self.remote_version:
                print "are equal"
            else:
                print "update"


instance = sample_data()
instance.data_req()
