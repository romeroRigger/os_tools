# _*_ coding: utf-8 _*_
'''
__name__ = 'jobFinderMaya'
__author__ = 'Jaime Romero'
__license__ = 'Creative Commons Attribution-ShareAlike'
__revision__ = 3
'''
# TODO: auto-update data file, next revision


import maya.cmds as mc
from functools import partial
import json
import os
import re
import logging
import requests as requests
from lxml import html
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def ui():
    uiObject = jobFinderClass()


class jobFinderClass(object):
    '''A class to scrap data from internet'''

    def __init__(self, data_file='job_data.json',
                 folder_path='{}/data'.format(os.path.dirname(os.path.realpath(__file__))),
                 version_url='https://raw.githubusercontent.com/romeroRigger/CGjobs/master/version.html',
                 data_url='https://raw.githubusercontent.com/romeroRigger/CGjobs/master/job_data.json',
                 w_name='jobFinder', w_title='jr :: CG Job Finder', width=400, height=150):

        # variables and constants related with data
        self.file_path = '{}/{}'.format(folder_path, data_file)
        self.data_file = data_file
        self.folder_path = folder_path
        self.file_path = '{}/{}'.format(folder_path, data_file)
        self.version_url = version_url
        self.data_url = data_url

        # Variables related with UI
        self.w_name = w_name
        self.w_title = w_title
        self.width = width
        self.height = height
        self.job_lst = []
        self.country_lst = []
        self.widgets = {"jobTitle": "", "country": ""}
        self.data_find = dict()

        # Build the UI
        self.__build__()

    def __build__(self):
        '''This function will house all the commands to build the UI'''
        if mc.window(self.w_name, ex=True):
            mc.deleteUI(self.w_name)

        # Create the window and its contents
        self.window = mc.window(self.w_name, t=self.w_title, w=self.width, h=self.height,
                                menuBar=True, s=False, mnb=False, mxb=False)

        self.main_layout = mc.columnLayout('main_layout', w=self.width, rs=5)

        # Main textfield and option menu fields
        self.w = self.width / 2 - 10
        mc.separator(h=5)
        mc.rowLayout('buttonsLayout', nc=3, cw=[(1, self.w), (2, self.w)])
        self.text_job = mc.textFieldGrp('text_job', w=self.w, cw2=[
            self.w * 0.25, self.w * 0.7], h=20, l="  What :", cal=(1, "left"), tcc=partial(self.job_refresh))
        self.menu_country = mc.optionMenu('menu_country', w=self.w, h=20,
                                          l='Where :', cc=partial(self.country_refresh))

        # Method call to populate the country menu list
        self.populate_country()
        for each in sorted(set(self.country_lst)):
            mc.menuItem(l=each)

        # button control using partial to function call
        mc.setParent(self.main_layout)
        mc.separator(h=5)
        mc.columnLayout(w=self.width, cw=self.width, cat=('both', 20))
        mc.button(l='Find Jobs', h=20, bgc=(0, 0.75, 1), c=partial(self.job_what_where))
        mc.separator(h=10)

        # text scroll list
        self.full_list = mc.textScrollList('full_list', sc=partial(self.select_sclick), ams=False, w=300)
        mc.textScrollList(self.full_list, e=True, ra=True)

        # Menu options
        mc.menu(label='Help', helpMenu=True)
        mc.menuItem('update_data', label='Update jobs data', c=partial(self.request_version))
        mc.menuItem('posting', label='your own posting')
        mc.menuItem(divider=True)
        mc.menuItem('about', label='by @romerorigger', c=partial(self.about_dialog))

        # Show the window and edit its size
        mc.showWindow(self.w_name)

    # Methods to build the info into the UI
    def _open_file(self, *args):
        with open(self.file_path) as job_data:
            self.data = json.load(job_data)

    def populate_country(self, *args):
        '''
        Method to call to populate the country menu list
        '''
        self._open_file()
        self.country_lst = []
        for p in self.data['jobs']:
            self.country_lst.append(p['country'])

    def job_what_where(self, *args):
        self._open_file()
        self.data_find.clear()
        self.job_idx = 0
        for p in self.data['jobs']:
            if re.search(self.widgets['country'], p['country'], re.IGNORECASE) and re.search(self.widgets['jobTitle'], p['jobTitle'], re.IGNORECASE):
                self.job_idx += 1
                self.data_find[self.job_idx] = p
        self.populate_text_scroll()

    def populate_text_scroll(self, *args):
        self.scroll_idx = 0
        mc.textScrollList('full_list', e=True, ra=True)
        for each in self.data_find.values():
            self.scroll_idx += 1
            mc.textScrollList('full_list', e=True, a=each['jobTitle'], utg=self.scroll_idx)

    def job_refresh(self, item, *args):
        '''Refresh the widgets job'''
        self.widgets['jobTitle'] = item

    def country_refresh(self, item, *args):
        '''Refresh the widgets country'''
        self.widgets['country'] = item

    def select_sclick(self, *args):
        self.scroll_sel = mc.textScrollList('full_list', q=True, sii=True)
        self.info_job = json.dumps(self.data_find[self.scroll_sel[0]], indent=2, sort_keys=True)
        self.launch_dialog()  # TODO: arrange information and contact info button

    def launch_dialog(self, *args):
        result = mc.confirmDialog(title='Contact Information:',
                                  message=self.info_job,  # TODO: arrange information
                                  # message="under develop.... \n jobTitle: Animator, 2D - Lead (Key poses and animation)\nstudio: Industrial Brothers\ncity: Toronto\ndate: 2018-02-12\nSoftware: CelAction, Flash, Maya,\n",
                                  button=['Contact', 'Close'],
                                  defaultButton='Close', cancelButton='Close', dismissString='Close')

        if result == 'Contact':
            mc.showHelp('http://google.com', absolute=True)

    def about_dialog(self, *args):
        mc.launch(web="http://romerorigger.com/")

    # Methods to help the file updating
    def request_version(self, *args):
        try:
            response = requests.get(self.data_url, timeout=2)
            if response.status_code == 200:
                self.online_version()
        except Exception, e:
            logger.error('Please connect your machine to internet')

    def online_version(self, *args):
        page = requests.get(self.version_url)
        tree = html.fromstring(page.content)
        self.remote_version = tree.xpath('//div[@id="version"]/text()')[0]
        self.offline_version()

    def offline_version(self, *args):
        with open(self.file_path) as job_data:
            data = json.load(job_data)
            self.local_version = data["version"]
            if self.local_version == self.remote_version:
                self.dialog_message = 'The current version is {}, your data is up to date'.format(self.remote_version)
                self.update_dialog()
            else:
                self.dialog_message = 'new version {}\nPlease Download the update \nand replace the file in: \njr_jobFinder/data'.format(
                    self.local_version, self.remote_version)
                self.update_dialog()

    def update_dialog(self, *args):
        result = mc.confirmDialog(title='Update info:',
                                  message=self.dialog_message,
                                  button=['Download', 'Close'],
                                  defaultButton='Close', cancelButton='Close', dismissString='Close')
        if result == 'Download':
            mc.launch(web=self.data_url)


# Launch
if __name__ == "__main__":
    ui()
